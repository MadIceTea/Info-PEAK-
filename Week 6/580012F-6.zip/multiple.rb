def multiple(p,n)
    n % p == 0
end