def pnum(p)
	(2**(p-1)) * ((2**p)-1)
end